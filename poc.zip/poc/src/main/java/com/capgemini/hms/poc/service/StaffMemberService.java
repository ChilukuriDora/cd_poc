package com.capgemini.hms.poc.service;

import java.util.List;

import com.capgemini.hms.poc.model.StaffMember;

public interface StaffMemberService {
	public List<StaffMember> getAllStaff();

	public StaffMember getStaffMemberById(int id);

	public int saveOrUpdate(StaffMember member);

	public void delete(int id);

}
