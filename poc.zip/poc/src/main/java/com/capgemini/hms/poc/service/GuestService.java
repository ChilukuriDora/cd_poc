package com.capgemini.hms.poc.service;

import java.util.List;

import com.capgemini.hms.poc.model.Guest;

public interface GuestService {
	public List<Guest> getAllGuests();

	public Guest getGuestById(int id);

	public int saveOrUpdate(Guest member);

	public void delete(int id);
}
