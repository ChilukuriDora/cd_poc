package com.capgemini.hms.poc.service;

import java.util.List;

import com.capgemini.hms.poc.model.Reservation;

public interface ReservationService {

	public List<Reservation> getAllRooms();

	public Reservation getReservationById(int id);

	public int saveOrUpdate(Reservation room);

	public void delete(int id);

}
