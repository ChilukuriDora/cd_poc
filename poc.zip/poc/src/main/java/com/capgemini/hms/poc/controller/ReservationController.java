package com.capgemini.hms.poc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hms.poc.model.Reservation;
import com.capgemini.hms.poc.service.ReservationService;

@RestController
public class ReservationController {

	@Autowired
	ReservationService reservationService;

	@GetMapping("/hms/rooms")
	private List<Reservation> getAllRooms() {
		return reservationService.getAllRooms();
	}

	@GetMapping("/hms/getRoom/{roomCode}")
	private Reservation getRoom(@PathVariable("roomCode") int roomCode) {
		return reservationService.getReservationById(roomCode);
	}

	@DeleteMapping("/hms/delete/{roomCode}")
	private void deleteroom(@PathVariable("roomCode") int roomCode) {
		reservationService.delete(roomCode);
	}

	@PostMapping("/hms/saveRoom")
	public ResponseEntity<String> saveRoom(@RequestBody Reservation room) {
		int i = reservationService.saveOrUpdate(room);
		return new ResponseEntity<String>("Registration has been done successfully with id:" + i, HttpStatus.CREATED);
	}

}
