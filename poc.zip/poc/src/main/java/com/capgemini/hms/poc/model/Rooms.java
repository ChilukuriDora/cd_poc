package com.capgemini.hms.poc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Rooms {

	@Id
	private int roomCode;
	@Column
	private String name;

}
