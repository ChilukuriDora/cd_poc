package com.capgemini.hms.poc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hms.poc.model.StaffMember;
import com.capgemini.hms.poc.service.StaffMemberService;

@RestController
public class StaffMemeberController {

	@Autowired
	StaffMemberService staffMemberService;

	@GetMapping("/staffMember")
	private List<StaffMember> getAllStaffMember() {
		return staffMemberService.getAllStaff();
	}

	@GetMapping("/staffMember/{id}")
	private StaffMember getStaffMember(@PathVariable("id") int id) {
		return staffMemberService.getStaffMemberById(id);
	}

	@DeleteMapping("/staffMember/{id}")
	private void deleteStaffMember(@PathVariable("id") int id) {
		staffMemberService.delete(id);

	}

	@PostMapping("/staffMember")
	private int saveStaffMember(@RequestBody StaffMember staffMember) {
		staffMemberService.saveOrUpdate(staffMember);
		return staffMember.getStaffCode();
	}
}
