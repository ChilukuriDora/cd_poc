package com.capgemini.hms.poc.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.hms.poc.model.Reservation;

public interface RoomRepository extends CrudRepository<Reservation, Integer> {

}
