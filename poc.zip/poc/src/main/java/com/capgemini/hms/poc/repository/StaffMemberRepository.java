package com.capgemini.hms.poc.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.hms.poc.model.StaffMember;

public interface StaffMemberRepository extends CrudRepository<StaffMember, Integer> {

}
