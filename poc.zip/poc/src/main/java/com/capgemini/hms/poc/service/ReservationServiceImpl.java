package com.capgemini.hms.poc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hms.poc.model.Reservation;
import com.capgemini.hms.poc.repository.RoomRepository;

@Service
public class ReservationServiceImpl implements ReservationService {

	@Autowired
	RoomRepository roomRepository;

	public List<Reservation> getAllRooms() {

		List<Reservation> rooms = new ArrayList<Reservation>();
		roomRepository.findAll().forEach(room -> rooms.add(room));
		return rooms;

	}

	public Reservation getReservationById(int id) {

		return roomRepository.findById(id).get();

	}

	public int saveOrUpdate(Reservation room) {
		Reservation r = (Reservation) roomRepository.save(room);
		return r.getId();
	}

	public void delete(int id) {
		roomRepository.deleteById(id);
	}

}
