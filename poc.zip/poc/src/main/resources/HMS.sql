DROP TABLE IF EXISTS Reservation;
CREATE TABLE Reservation  ( 
id INT AUTO_INCREMENT  PRIMARY KEY,
roomCode INT,
numberOfChildren INT,
numberOfAdults INT,
checkInDate date,
checkOutDate date,
status boolean,
numberOfNights INT
);

DROP TABLE IF EXISTS ROOMS;  
CREATE TABLE ROOMS(  
roomCode INT,  
name VARCHAR(50) NOT NULL, 
);  

DROP TABLE IF EXISTS Guest;
CREATE TABLE Guest  (
memberCode INT AUTO_INCREMENT  PRIMARY KEY,
phoneNumber INT,
company VARCHAR,
guestName VARCHAR,
eMail VARCHAR,
gender VARCHAR,
address VARCHAR
);

DROP TABLE IF EXISTS StaffMember;
CREATE TABLE StaffMember  (
    staffCode INT AUTO_INCREMENT  PRIMARY KEY,
    nic INT,
    salary INT,
    employeeName VARCHAR,
    occupation VARCHAR,
    eMail VARCHAR,
    age INT,
    address VARCHAR
);

INSERT INTO ROOMS VALUES (1, 'Vijayawada');    
INSERT INTO ROOMS VALUES (2, 'Hyderabad');    
INSERT INTO ROOMS VALUES (3, 'Bangalore');
INSERT INTO ROOMS VALUES (4, 'Mumbai');
INSERT INTO ROOMS VALUES (5, 'Pune');
INSERT INTO ROOMS VALUES (6, 'Chennai');
INSERT INTO ROOMS VALUES (7, 'New Delhi');
