package com.capgemini.hms.poc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.hms.poc.model.Guest;
import com.capgemini.hms.poc.service.GuestService;

@RestController
public class GuestController {
	
	@Autowired
	GuestService guestService;

	@GetMapping("/guest")
	private List<Guest> getAllGuest() {
		return guestService.getAllGuests();
	}

	@GetMapping("/guest/{id}")
	private Guest getGuest(@PathVariable("id") int id) {
		return guestService.getGuestById(id);
	}

	@DeleteMapping("/guest/{id}")
	private void deleteGuest(@PathVariable("id") int id) {
		guestService.delete(id);
	}

	@PostMapping("/guest")
	private int saveGuest(@RequestBody Guest guest) {
		guestService.saveOrUpdate(guest);
		return guest.getMemberCode();
	}
}
