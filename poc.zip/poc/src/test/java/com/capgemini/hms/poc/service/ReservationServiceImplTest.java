package com.capgemini.hms.poc.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.capgemini.hms.poc.model.Reservation;
import com.capgemini.hms.poc.repository.RoomRepository;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class ReservationServiceImplTest {
	
	@InjectMocks
	private ReservationService reservationServiceImpl = new ReservationServiceImpl();
	
	@Mock
	private RoomRepository roomRepository;
	
	
	@Test
	public void saveReservationTest(){

		Reservation reservation = new Reservation();
        reservation.setId(1);
        reservation.setRoomCode(143);
        reservation.setNumberOfChildren(2);
        reservation.setNumberOfAdults(2);
        reservation.setStatus(true);
        reservation.setNumberOfNights(3);
 
        when(roomRepository.save(any(Reservation.class))).thenReturn(new Reservation());
		int id = reservationServiceImpl.saveOrUpdate(reservation);
		assertThat(id);
	}

}
