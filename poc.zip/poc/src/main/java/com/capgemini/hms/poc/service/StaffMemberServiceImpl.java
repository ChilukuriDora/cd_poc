package com.capgemini.hms.poc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hms.poc.model.StaffMember;
import com.capgemini.hms.poc.repository.StaffMemberRepository;

@Service
public class StaffMemberServiceImpl implements StaffMemberService {

	@Autowired
	StaffMemberRepository staffMemberRepository;

	public StaffMember getStaffMemberById(int id) {
		return staffMemberRepository.findById(id).get();
	}

	public int saveOrUpdate(StaffMember staffMember) {
		StaffMember s = (StaffMember) staffMemberRepository.save(staffMember);
		return s.getStaffCode();

	}

	public void delete(int id) {
		staffMemberRepository.deleteById(id);
	}

	@Override
	public List<StaffMember> getAllStaff() {
		List<StaffMember> staffmembers = new ArrayList<StaffMember>();
		staffMemberRepository.findAll().forEach(staffmember -> staffmembers.add(staffmember));
		return staffmembers;

	}

}
