DROP TABLE IF EXISTS Guest;
CREATE TABLE Guest  (
memberCode INT AUTO_INCREMENT  PRIMARY KEY,
phoneNumber INT,
company VARCHAR,
guestName VARCHAR,
eMail VARCHAR,
gender VARCHAR,
address VARCHAR
);