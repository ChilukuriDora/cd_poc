package com.capgemini.hms.poc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.hms.poc.model.Guest;
import com.capgemini.hms.poc.repository.GuestRepository;

@Service
public class GuestServiceImpl implements GuestService{
	@Autowired
	GuestRepository guestRepository;


	public Guest getGuestById(int id) {
		return guestRepository.findById(id).get();
	}

	public void delete(int id) {
		guestRepository.deleteById(id);
	}

	@Override
	public List<Guest> getAllGuests() {
		List<Guest> guests = new ArrayList<Guest>();
		guestRepository.findAll().forEach(guest -> guests.add(guest));
		return guests;
	}

	@Override
	public int saveOrUpdate(Guest member) {
		Guest g = guestRepository.save(member);
		return g.getMemberCode();
	}
}
